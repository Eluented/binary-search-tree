package com.sparta.anu;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


public class AppTest 
{

    @Test
    @DisplayName("")
    void test() {
     Assertions.assertEquals(1,1);
     }
}
